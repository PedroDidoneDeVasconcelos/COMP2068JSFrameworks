// routes/habits.js
const express = require('express');
const router = express.Router();
const Habit = require('../models/habit');

// GET /habits/my-habits - Show all habits
router.get('/my-habits', async (req, res) => {
  try {
    // Fetch all habits from the database
    const habits = await Habit.find();
    // Render the 'my-habits' view and pass the habits data
    res.render('my-habits', { habits });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// POST /habits/edit/:id - To mark a habit as completed
router.post('/edit/:id', async (req, res) => {
  try {
    const habit = await Habit.findById(req.params.id);
    if (!habit) {
      return res.status(404).send('Habit not found');
    }

    if (habit.status === 'Completed') {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);

      if (habit.lastCompleted && new Date(habit.lastCompleted).toDateString() === yesterday.toDateString()) {
        habit.streak++;
      } else {
        habit.streak = 1;
      }

      habit.lastCompleted = new Date();
    }

    await habit.save();
    res.status(200).send(habit);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

module.exports = router;
